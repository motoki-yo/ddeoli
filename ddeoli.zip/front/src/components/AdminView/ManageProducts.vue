<template>
<main>
        <!-- Products table START !-->
            <div class="table-responsive">
                <div class="table-wrapper">
                    <div class="table-title">
                        <div class="row">
                            <div class="col">
                                <h4 class="mtext-105">
                                    Manage products
                                </h4>
                            </div>

                            <div class="col">
                                <button @click="showAddProductModal = true" class="btn btn-success" data-toggle="modal"><i class="fa-solid fa-circle-plus"></i> <span>Add New Product</span></button>
                            </div>
                        </div>
                    </div>
                    <table class="table table-striped table-hover mb-0">
                        <thead>
                            <tr>
                                <th>Image</th>
                                <th>Name</th>
                                <th>Collection</th>
                                <th>Price</th>
                                <th colspan="2">Description</th>
                                <th>Quantity available</th>
                                <th>Quantity Sold</th>
                                <th>Sizes</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <!-- Product load !-->
                        <tbody >
                            <!-- If no products are registred !-->
                            <tr v-if="!products.length">
                                <td colspan="10" class="text-center">No products</td>
                            </tr>

                            <!-- Single product !-->
                            <tr v-else v-for="product in products" :product="product" :key="product.id" >
                                <td><img class = "avatar" :src="product.img" :alt="product.description"></td>
                                <td>{{ product.name }}</td>
                                <td>{{ product.collectionType }}</td>
                                <td>$ {{ product.price }}</td>
                                <td colspan="2">{{ product.description}} </td>
                                <td> {{ product.qtyInInventory }}</td>
                                <td> {{ product.qtyInInventory * Math.floor(Math.random() * 10) }}</td>
                                <td> {{ product.sizes.join(', ') }}</td>
                                <td>
                                    <button productTable="product" @click="sendProductInfoModal(product); showEditProductModal = true"  class="edit" data-toggle="modal"><i class="fa-solid fa-pen-to-square"></i></button>
                                    <button @click="showDeleteProductModal = true"  class="delete" data-toggle="modal"><i class="fa-solid fa-trash"></i></button>
                                </td>
                            </tr>
                            
                        </tbody>
                    </table>
                    
                </div>
        </div> <!-- Products table END !-->
        
        <!-- Add Modal HTML -->
        <vue-final-modal v-model="showAddProductModal" classes="modal-container" name="addProduct">   
            <div class="modal-dialog">
                <div class="modal-content">
                    <form validate>
                        <div class="modal-header">						
                            <h4 class="modal-title">Add product</h4>
                            <button class="modal__close" @click="showAddProductModal = false">
                                <i class="fa-solid fa-xmark"></i>
                            </button>
                        </div>
                        <div class="modal-body">	
                            <div class="form-group">
                                <label>Image</label>
                                <input type="file" class="form-control" required>
                            </div>
                            <div class="form-group">
                                <label>Name</label>
                                <input type="text" class="form-control" required>
                            </div>
                            <div class="form-group">
                                <label>Collection</label>
                                <select class="form-select form-control" aria-label="Default select example" required>
                                    <option selected disabled>Open this select menu</option>
                                    <option value="1">Synk Dive</option>
                                    <option value="2">Wildside</option>
                                    <option value="3">Maniac</option>
                                </select>
                            </div>                            				
                            <div class="row">
                                <div class="form-group col-6">
                                    <label>Price</label>
                                    <input type="text" class="form-control" required>
                                </div>
                                <div class="form-group col-6">
                                    <label>Quantity in stock</label>
                                    <input type="text" class="form-control" required>
                                </div>
                            </div>
                            <div class="form-group">
                                <label>Description</label>
                               <textarea class="form-control" required></textarea>
                            </div>

                            <div class="form-group">
                                <label>Sizes</label>
                                <div class="check-wrap">
                                    <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="checkbox" id="inlineCheckbox1" value="option1">
                                    <label class="form-check-label" for="inlineCheckbox1">XS</label>
                                    </div>
                                    <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="checkbox" id="inlineCheckbox2" value="option2">
                                    <label class="form-check-label" for="inlineCheckbox2">S</label>
                                    </div>
                                    <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="checkbox" id="inlineCheckbox3" value="option3">
                                    <label class="form-check-label" for="inlineCheckbox3">M</label>
                                    </div>
                                    <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="checkbox" id="inlineCheckbox3" value="option3">
                                    <label class="form-check-label" for="inlineCheckbox3">L</label>
                                    </div>
                                    <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="checkbox" id="inlineCheckbox3" value="option3">
                                    <label class="form-check-label" for="inlineCheckbox3">XL</label>
                                    </div>
                                </div>
                            </div>						
                        </div>
                        <div class="modal-footer modal__action">
                            <button @click="showModal = false" class="btn btn-success">Add</button>
                            <button @click="showAddProductModal = false" class="btn btn-default">Cancel</button>
                        </div>
                    </form>
                </div>
            </div>
        </vue-final-modal>

        <!-- Edit Modal HTML -->
       <vue-final-modal v-model="showEditProductModal" classes="modal-container" name="editUser">   
            <div class="modal-dialog">
                <div class="modal-content">
                    <form>
                        <div class="modal-header">						
                            <h4 class="modal-title">Edit product</h4>
                            <button class="modal__close" @click="showEditProductModal = false">
                                <i class="fa-solid fa-xmark"></i>
                            </button>
                        </div>
                        <div class="modal-body">	
                            <div class="form-group">
                                <label>Image</label>
                                <input type="file" class="form-control" required>
                            </div>
                            <div class="form-group">
                                <label>Name</label>
                                <input type="text" class="form-control" :value="selectedProduct.name" required>
                            </div>
                            <div class="form-group">
                                <label>Collection</label>
                                <select class="form-select form-control" aria-label="Default select example">
                                    <option value="Synk Dive" :selected= " selectedProduct.collectionType === 'Synk Dive' ">Synk Dive</option>
                                    <option value="Wildside" :selected= " selectedProduct.collectionType === 'Wildside' ">Wildside</option>
                                    <option value="Maniac" :selected= " selectedProduct.collectionType === 'Maniac' ">Maniac</option>
                                </select>
                            </div>                            				
                            <div class="row">
                                <div class="form-group col-6">
                                    <label>Price</label>
                                    <input type="text" class="form-control" :value="selectedProduct.price" required>
                                </div>
                                <div class="form-group col-6">
                                    <label>Quantity in stock</label>
                                    <input type="text" class="form-control" :value="selectedProduct.qtyInInventory" required>
                                </div>
                            </div>
                            <div class="form-group">
                                <label>Description</label>
                               <textarea class="form-control" :value="selectedProduct.description" required></textarea>
                            </div>

                            <div class="form-group">
                                <label>Sizes</label>
                                <div class="check-wrap">
                                    <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="checkbox" id="inlineCheckbox1" value="XS" :checked="selectedProduct.sizes?.includes('XS')">
                                    <label class="form-check-label" for="inlineCheckbox1">XS</label>
                                    </div>
                                    <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="checkbox" id="inlineCheckbox2" value="S" :checked="selectedProduct.sizes?.includes('S')">
                                    <label class="form-check-label" for="inlineCheckbox2">S</label>
                                    </div>
                                    <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="checkbox" id="inlineCheckbox3" value="M" :checked="selectedProduct.sizes?.includes('M')">
                                    <label class="form-check-label" for="inlineCheckbox3">M</label>
                                    </div>
                                    <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="checkbox" id="inlineCheckbox3" value="L" :checked="selectedProduct.sizes?.includes('L')">
                                    <label class="form-check-label" for="inlineCheckbox3">L</label>
                                    </div>
                                    <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="checkbox" id="inlineCheckbox3" value="XL" :checked="selectedProduct.sizes?.includes('XL')">
                                    <label class="form-check-label" for="inlineCheckbox3">XL</label>
                                    </div>
                                </div>
                            </div>						
                        </div>
                        <div class="modal-footer modal__action">
                            <button @click="showEditProductModal = false" class="btn btn-success">Save changes</button>
                            <button @click="showEditProductModal = false" class="btn btn-default">Cancel</button>
                        </div>
                    </form>
                </div>
            </div>
        </vue-final-modal>

        <!-- Delete Modal HTML -->
       <vue-final-modal v-model="showDeleteProductModal" classes="modal-container" name="deletUser">   
            <div class="modal-dialog">
                <div class="modal-content">
                    <form>
                        <div class="modal-header">						
                            <h4 class="modal-title">Delete Product</h4>
                            <button class="modal__close" @click="showDeleteProductModal = false">
                                <i class="fa-solid fa-xmark"></i>
                            </button>
                        </div>
                        <div class="modal-body">					
                            <p>Are you sure you want to delete these Records?</p>
                            <p class="text-warning"><small>This action cannot be undone.</small></p>
                        </div>
                            <div class="modal-footer modal__action">
                                <button @click="showDeleteProductModal = false" class="btn btn-success">Delete</button>
                                <button @click="showDeleteProductModal = false" class="btn btn-default">Cancel</button>
                            </div>
                    </form>
                </div>
            </div>
        </vue-final-modal>


</main>
</template>

<script>
import {computed} from 'vue';
import {useStore} from "vuex";

import { VueFinalModal } from 'vue-final-modal'


export default {
    name:'ManageProducts',
    props : ['product'],

    components: {
        VueFinalModal,
    },

    setup(){
        const store = useStore();
        
        let products = computed(function () {
        return store.state.products
        });

        return {
            products,
        }
    },

    data () {
        return {
            showModal: false,
            showAddProductModal:false,
            showEditProductModal:false,
            showDeleteProductModal:false,
            selectedProduct: '',
        }
    },

    methods: {
        sendProductInfoModal(tableProduct) {
            this.selectedProduct = tableProduct;
        }
    }


}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
@import '../../../public/assets/css/admin.css';

</style>